# -*- coding: utf-8 -*-

import xbmc
import xbmcgui
import xbmcplugin
import sys
import os
import re

try:
    HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 0
except Exception:
    HANDLE = 0

M3U_FILE = "/home/nunes/.kodi/userdata/addon_data/plugin.video.canaisbrasil/lista.m3u"

def listar_categorias():
    categorias = [
        ("TV Aberta", "aberta"),
        ("Esportes", "esportes"),
        ("HBO", "hbo"),
        ("Telecine", "telecine"),
        ("Discovery", "discovery"),
        ("Filmes e Séries", "filmes"),
        ("Documentários", "documentarios"),
        ("Infantil", "infantil"),
        ("Música", "musica"),
        ("Notícias", "noticias"),
        ("Outros", "outros")
    ]
    for nome, modo in categorias:
        url = "{}?mode={}".format(sys.argv[0], modo)
        lista_item = xbmcgui.ListItem(label=nome)
        xbmcplugin.addDirectoryItem(HANDLE, url, lista_item, True)
    xbmcplugin.endOfDirectory(HANDLE)

def filtrar_e_mostrar_canais(categoria_alvo):
    if not os.path.exists(M3U_FILE):
        xbmcgui.Dialog().ok("StreamKodi", "Lista M3U não encontrada!")
        return

    with open(M3U_FILE, "r", encoding="utf-8", errors="ignore") as f:
        linhas = f.readlines()

    canal_atual = {}
    for linha in linhas:
        linha = linha.strip()
        if not linha:
            continue
            
        if linha.startswith("#EXTINF:"):
            partes = linha.split(",")
            canal_atual["nome"] = partes[-1].strip() if len(partes) > 1 else "Canal Sem Nome"
            match_group = re.search(r'group-title="([^"]+)"', linha)
            canal_atual["grupo"] = match_group.group(1).lower() if match_group else ""
            match_logo = re.search(r'tvg-logo="([^"]+)"', linha)
            canal_atual["logo"] = match_logo.group(1) if match_logo else ""
            
        elif linha.startswith("http") or linha.startswith("rtmp"):
            if "nome" in canal_atual:
                n = canal_atual["nome"].lower()
                g = canal_atual["grupo"]
                
                eh_telecine = "telecine" in n or "telecine" in g
                eh_discovery = ("discovery" in n or "disc." in n or "discovery" in g) and "kids" not in n
                eh_hbo = "hbo" in n or "hbo" in g
                
                eh_infantil = any(x in n for x in ["cartoon", "disney", "nick", "gloob", "infantil", "tooncast", "boomerang", "tv rá tim bum", "kids", "fox kids", "animax", "anime", "googles"]) or "infantil" in g
                eh_noticia = any(x in n for x in ["news", "cnn", "jovem pan", "jp ", "notícias", "noticia", "cnbc", "cbs", "euronews", "videonews"]) or "notícias" in g or "noticias" in g
                eh_esporte = any(x in n for x in ["sport", "espn", "premiere", "combate", "fox premium", "conmebol", "nfl", "ufc", "futebol", "daon"]) or "esporte" in g or "esportes" in g
                eh_doc = (any(x in n for x in ["animal", "history", "h2", "nat geo", "national", "geographic", "geo", "science", "wild", "theater", "turbo", "world", "hgtv", "tlc", "home & health", "h&h", "emergência", "id hd", "doc."]) or "documentários" in g or "documentarios" in g or "variedades" in g) and not (eh_infantil or eh_discovery)
                eh_musica = any(x in n for x in ["mtv", "multishow", "bis ", "music", "música", "sertanejo", "funk", "antena 1", "retrô", "retro", "zumbis", "gaming", "ubisoft", "shore", "reality", "ridiculousness"]) or "música" in g or "musica" in g
                eh_filme = (any(x in n for x in ["filme", "cine", "pix", "warner", "sony", "universal", "axn", "fx", "a&e", "amc", "tnt", "space", "paramount", "star trek", "series", "séries", "filmelier", "suspense", "classique", "cinerama", "monde", "espanto", "hallo!", "movie sphere", "novelas"]) or "filmes" in g or "séries" in g) and not (eh_hbo or eh_telecine or eh_doc or eh_infantil or eh_noticia or eh_musica)
                eh_aberto = (any(x in n for x in ["globo", "sbt", "band", "record", "redetv", "cultura", "tv brasil", "difusora", "pampa", "sictv", "liberal", "rba tv", "modelo", "arapuan", "viva", "amor bandido"]) or "aberta" in g or "tv aberta" in g) and not (eh_noticia or eh_esporte or eh_filme or eh_doc or eh_musica or eh_telecine or eh_discovery or eh_hbo)

                corresponde = False
                if categoria_alvo == "aberta" and eh_aberto: corresponde = True
                elif categoria_alvo == "esportes" and eh_esporte: corresponde = True
                elif categoria_alvo == "hbo" and eh_hbo: corresponde = True
                elif categoria_alvo == "telecine" and eh_telecine: corresponde = True
                elif categoria_alvo == "discovery" and eh_discovery: corresponde = True
                elif categoria_alvo == "filmes" and eh_filme: corresponde = True
                elif categoria_alvo == "documentarios" and eh_doc: coloque = True; corresponde = True
                elif categoria_alvo == "infantil" and eh_infantil: corresponde = True
                elif categoria_alvo == "musica" and eh_musica: corresponde = True
                elif categoria_alvo == "noticias" and eh_noticia: corresponde = True
                elif categoria_alvo == "outros" and not (eh_aberto or eh_esporte or eh_hbo or eh_telecine or eh_discovery or eh_filme or eh_doc or eh_infantil or eh_musica or eh_noticia): corresponde = True
                
                if corresponde:
                    lista_item = xbmcgui.ListItem(label=canal_atual["nome"])
                    lista_item.setArt({"thumb": canal_atual["logo"], "icon": canal_atual["logo"]})
                    lista_item.setInfo("video", {"title": canal_atual["nome"], "mediatype": "video"})
                    lista_item.setProperty("IsPlayable", "true")
                    xbmcplugin.addDirectoryItem(HANDLE, linha, lista_item, False)
            canal_atual = {}
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    paramstring = sys.argv[2] if len(sys.argv) > 2 else ""
    if "mode=aberta" in paramstring:
        filtrar_e_mostrar_canais("aberta")
    elif "mode=esportes" in paramstring:
        filtrar_e_mostrar_canais("esportes")
    elif "mode=hbo" in paramstring:
        filtrar_e_mostrar_canais("hbo")
    elif "mode=telecine" in paramstring:
        filtrar_e_mostrar_canais("telecine")
    elif "mode=discovery" in paramstring:
        filtrar_e_mostrar_canais("discovery")
    elif "mode=filmes" in paramstring:
        filtrar_e_mostrar_canais("filmes")
    elif "mode=documentarios" in paramstring:
        filtrar_e_mostrar_canais("documentarios")
    elif "mode=infantil" in paramstring:
        filtrar_e_mostrar_canais("infantil")
    elif "mode=musica" in paramstring:
        filtrar_e_mostrar_canais("musica")
    elif "mode=noticias" in paramstring:
        filtrar_e_mostrar_canais("noticias")
    elif "mode=outros" in paramstring:
        filtrar_e_mostrar_canais("outros")
    else:
        listar_categorias()
